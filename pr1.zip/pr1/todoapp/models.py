from django.db import models
from django.contrib.auth.models import User


class Todo(models.Model):
    Заголовок = models.CharField(max_length=100)
    Информация = models.TextField(blank=True)

    created = models.DateTimeField(auto_now_add=True)
    Готово = models.BooleanField(default=False)

    Пользователь = models.ForeignKey(User, on_delete=models.CASCADE)

    def __str__(self):
        return self.Заголовок
