from django.urls import path
from . import views


urlpatterns = [
    path('todoapp/', views.TodoList.as_view()),
    path('todoapp/create/', views.TodoListCreate.as_view()),
    path('todoapp/<int:pk>', views.TodoRetrieveUpdateDestroy.as_view()),
    path('todoapp/<int:pk>/complete', views.TodoToggleComplete.as_view()),
    path('signup/', views.signup),
]