from django.urls import path, include
from .import views


urlpatterns = [
    path('todoapp/', views.TodoList.as_view())
]